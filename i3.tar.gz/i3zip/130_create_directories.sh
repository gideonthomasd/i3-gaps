#!/bin/bash

[ -d $HOME"/.config" ] || mkdir -p $HOME"/.config"
[ -d $HOME"/.config/i3" ] || mkdir -p $HOME"/.config/i3"
[ -d $HOME"/.config/i3blocks" ] || mkdir -p $HOME"/.config/i3blocks"
#[ -d $HOME"/.config/polybar" ] || mkdir -p $HOME"/.config/polybar"
[ -d $HOME"/.config/termite" ] || mkdir -p $HOME"/.config/termite"
[ -d $HOME"/.config/rofi" ] || mkdir -p $HOME"/.config/rofi"
[ -d $HOME"/.config/jgmenu" ] || mkdir -p $HOME"/.config/jgmenu"

cp -Rf ~/.config ~/.config-backup-$(date +%Y.%m.%d-%H.%M.%S)

cd i3
cp -r * ~/.config/i3
cd ..

cd i3blocks
cp -r * ~/.config/i3blocks
cd ..

#cd polybar
#cp -r * ~/.config/polybar
#cd ..

cd termite
cp -r * ~/.config/termite
cd ..

cd rofi
cp -r * ~/.config/rofi
cd ..

cd jgmenu
cp -r * ~/.config/jgmenu
cd ..

mv ~/.bashrc ~/.bashrc-$(date +%Y.%m.%d-%H.%M.%S)
cp bashrc ~/.bashrc

git clone  https://github.com/salman-abedin/devour.git
cd devour
sudo make install
echo "All done"
cd ..


#cp -arf bspwm ~/.config/bspwm
#cp -arf sxhkd ~/.config/sxhkd
#cp -arf polybar ~/.config/polybar

#cd test2
#cd bspwm
#cp -r * ~/mythetest
#cd ..
#cd ..
#pwd
